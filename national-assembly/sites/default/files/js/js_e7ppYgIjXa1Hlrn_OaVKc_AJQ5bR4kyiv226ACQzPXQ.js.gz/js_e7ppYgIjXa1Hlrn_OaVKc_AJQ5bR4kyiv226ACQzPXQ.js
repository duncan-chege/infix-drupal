/* @license GNU-GPL-2.0-or-later https://www.drupal.org/licensing/faq */
;
document.addEventListener("DOMContentLoaded",function(){let splide_hero=new Splide('.splide.hero-images',{type:'loop',perPage:1,autoplay:true,speed:300});splide_hero.mount();});;
